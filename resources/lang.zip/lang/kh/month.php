<?php
	return [
		'anuary' => 'មករា',
        'february' => 'កុម្ភៈ',
        'march' => 'មីនា',
        'april' => 'មេសា',
        'may' => 'ឧសភា',
        'june' => 'មិថុនា',
       'july' => 'កក្កដា',
        'august' => 'សីហា',
        'september' => 'កញ្ញា',
        'october' => 'តុលា',
        'november' => 'វិច្ឆិកា',
        'december' => 'ធ្នូ'
	];